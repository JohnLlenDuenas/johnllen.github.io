package com.johnllen.matchup.play;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.johnllen.matchup.R;
import com.johnllen.matchup.adapter.gameadapter.CardAdapter;
import com.johnllen.matchup.game.PopulateCard;


public class RoundTwo extends Fragment {

    RecyclerView recyclerView;

    TextView gameScore, animScore;
    ImageView backBtn, infoBtn;





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_round_two, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.animals_card);
        backBtn = view.findViewById(R.id.back_btn);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        PopulateCard populateCard = new PopulateCard(6);
        CardAdapter cardAdapter = new CardAdapter(populateCard.populateCard(), getContext(), gameScore, animScore, populateCard.getTotalAnimals(), getFragmentManager(), "Round 2");
        recyclerView.setAdapter(cardAdapter);


        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });


    }
}