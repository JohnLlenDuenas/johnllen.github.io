package com.johnllen.swappersandcheckers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    public String newActMessage = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void swapBtn(View view){
        EditText editText1 = findViewById(R.id.editText1);
        EditText editText2 = findViewById(R.id.editText2);
        String et1String = editText1.getText().toString();
        String et2String = editText2.getText().toString();
        editText1.setText(et2String);
        editText2.setText(et1String);
    }
    public void chkBtn(View view){
        EditText editText1 = findViewById(R.id.editText1);
        EditText editText2 = findViewById(R.id.editText2);
        String et1String = editText1.getText().toString();
        String et2String = editText2.getText().toString();
        if (et1String.equals(et2String)){
            newActMessage = "THE SAME";
        }else{
            newActMessage = "NOT THE SAME";
        }
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("key",newActMessage);
        startActivity(intent);
    }
}